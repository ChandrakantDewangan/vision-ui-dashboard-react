import React, { useState, useEffect } from 'react';
import './searchable-multi-select.css'

const SearchableMultiSelect = ({ options, onApply, onCancel }) => {
  const [selectedOptions, setSelectedOptions] = useState(options);
  const [tempSelectedOptions, setTempSelectedOptions] = useState([...options]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  useEffect(() => {
    setTempSelectedOptions([...options]);
  }, [options]);

  const handleCheckboxChange = (value) => {
    const updatedOptions = tempSelectedOptions.map((option) => ({
      ...option,
      selected: option.value === value ? !option.selected : option.selected,
    }));
    setTempSelectedOptions(updatedOptions);
  };

  const handleApply = () => {
    setSelectedOptions([...tempSelectedOptions]);
    onApply([...tempSelectedOptions]);
    setIsDropdownOpen(false);
  };

  const handleCancel = () => {
    setTempSelectedOptions([...selectedOptions]);
    onCancel();
    setIsDropdownOpen(false);
  };

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const filteredOptions = tempSelectedOptions.filter((option) =>
    option.label.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedCount = tempSelectedOptions.filter((option) => option.selected).length;

  return (
    <div className="dropdown-container">
      <div className="selected-options" onClick={toggleDropdown}>
        <span>{selectedCount > 0 ? `${selectedCount} selected` : 'Select Options'}</span>
        <i className={`arrow ${isDropdownOpen ? 'up' : 'down'}`} />
      </div>
      {isDropdownOpen && (
        <div className="dropdown">
          <input
            type="text"
            className='dropdown-search'
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <div className="filtered-options">
            {filteredOptions.length > 0 ? (
              <ul>
                {filteredOptions.map((option) => (
                  <li key={option.value}>
                    <label>
                      <input
                        type="checkbox"
                        value={option.value}
                        checked={option.selected}
                        onChange={() => handleCheckboxChange(option.value)}
                      />
                      {option.label}
                    </label>
                  </li>
                ))}
              </ul>
            ) : (
              <p>No options found.</p>
            )}
          </div>
          <div className="buttons">
            <button onClick={handleApply}>Apply</button>
            <button onClick={handleCancel}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchableMultiSelect;
