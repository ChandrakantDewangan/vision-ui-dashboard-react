import React, { useState } from 'react';
import SearchableMultiSelect from './SearchableMultiSelect';

const ParentComponent = () => {
  const allOptions = [
    { label: 'Option 1', value: 'Option 1', selected: false },
    { label: 'Option 2', value: 'Option 2', selected: false },
    { label: 'Option 3', value: 'Option 3', selected: true },
    { label: 'Option 4', value: 'Option 4', selected: false },
    { label: 'Option 5', value: 'Option 5', selected: false },
    { label: 'Option 6', value: 'Option 6', selected: false },
    { label: 'Option 7', value: 'Option 7', selected: false },
    { label: 'Option 8', value: 'Option 8', selected: false },
    { label: 'Option 9', value: 'Option 9', selected: false },
    { label: 'Option 10', value: 'Option 10', selected: false },
  ];

  const [selectedOptions, setSelectedOptions] = useState([...allOptions]);

  const handleApply = (selectedOptions) => {
    setSelectedOptions(selectedOptions);
  };

  const handleCancel = () => {
    console.log('Cancel button clicked');
  };

  return (
    <div>
      <h2>Parent Component</h2>
      <SearchableMultiSelect options={selectedOptions} onApply={handleApply} onCancel={handleCancel} />
      <div>
        <p>Selected Options:</p>
        <ul>
          {selectedOptions.map((option) => (
            <li key={option.value}>
              {option.label}: {option.selected ? 'Selected' : 'Not Selected'}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default ParentComponent;
