# Fix vertical menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/neelam123/pen/BLqgGm](https://codepen.io/neelam123/pen/BLqgGm).

