import React, { useState } from 'react';
import SearchableMultiSelect from './SearchableMultiSelect';

const ParentComponent = () => {
  const allOptions = [
    { label: 'Option 1', value: 'Option 1', selected: false },
    { label: 'Option 2', value: 'Option 2', selected: false },
    { label: 'Option 3', value: 'Option 3', selected: true },
    { label: 'Option 4', value: 'Option 4', selected: false },
    { label: 'Option 5', value: 'Option 5', selected: false },
  ];

  const [selectedOptions, setSelectedOptions] = useState([...allOptions]);

  const handleApply = (selectedOptions) => {
    // Do something with the selected options, e.g., update state in the parent component
    setSelectedOptions(selectedOptions);
  };

  const handleCancel = () => {
    // Handle cancel action if needed
    console.log('Cancel button clicked');
  };

  return (
    <div>
      <h2>Parent Component</h2>
      <SearchableMultiSelect options={selectedOptions} onApply={handleApply} onCancel={handleCancel} />
      <div>
        <p>Selected Options:</p>
        <ul>
          {selectedOptions.map((option) => (
            <li key={option.value}>
              {option.label}: {option.selected ? 'Selected' : 'Not Selected'}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default ParentComponent;
