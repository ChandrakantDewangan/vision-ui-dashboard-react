import React, { useState, useEffect } from 'react';

const SearchableMultiSelect = ({ options, onApply, onCancel }) => {
    const [selectedOptions, setSelectedOptions] = useState(options);
    const [tempSelectedOptions, setTempSelectedOptions] = useState([...options]);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        setTempSelectedOptions([...options]);
    }, [options]);

    const handleCheckboxChange = (value) => {
        const updatedOptions = tempSelectedOptions.map((option) => ({
            ...option,
            selected: option.value === value ? !option.selected : option.selected,
        }));
        setTempSelectedOptions(updatedOptions);
    };

    const handleApply = () => {
        setSelectedOptions([...tempSelectedOptions]);
        onApply([...tempSelectedOptions]);
    };

    const handleCancel = () => {
        setTempSelectedOptions([...selectedOptions]);
        onCancel();
    };

    const filteredOptions = tempSelectedOptions.filter((option) =>
        option.label.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div>
            <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />
            {filteredOptions.map((option) => (
                <div key={option.value}>
                    <label>
                        <input
                            type="checkbox"
                            value={option.value}
                            checked={option.selected}
                            onChange={() => handleCheckboxChange(option.value)}
                        />
                        {option.label}
                    </label>
                </div>
            ))}
            <div>
                <button onClick={handleApply}>Apply</button>
                <button onClick={handleCancel}>Cancel</button>
            </div>
        </div>
    );
};

export default SearchableMultiSelect;
