import React, { useState, useEffect } from 'react';

const SearchableMultiSelect = ({ options, initialSelectedOptions, onApply, onCancel }) => {
  const [selectedOptions, setSelectedOptions] = useState(initialSelectedOptions);
  const [tempSelectedOptions, setTempSelectedOptions] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    setTempSelectedOptions([...initialSelectedOptions]);
  }, [initialSelectedOptions]);

  const filteredOptions = options.filter((option) =>
    option.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCheckboxChange = (option) => {
    if (tempSelectedOptions.includes(option)) {
      setTempSelectedOptions(tempSelectedOptions.filter((item) => item !== option));
    } else {
      setTempSelectedOptions([...tempSelectedOptions, option]);
    }
  };

  const handleApply = () => {
    setSelectedOptions([...tempSelectedOptions]);
    onApply([...tempSelectedOptions]);
  };

  const handleCancel = () => {
    setTempSelectedOptions([...selectedOptions]);
    onCancel();
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Search..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      {filteredOptions.map((option) => (
        <div key={option}>
          <label>
            <input
              type="checkbox"
              value={option}
              checked={tempSelectedOptions.includes(option)}
              onChange={() => handleCheckboxChange(option)}
            />
            {option}
          </label>
        </div>
      ))}
      <div>
        <button onClick={handleApply}>Apply</button>
        <button onClick={handleCancel}>Cancel</button>
      </div>
    </div>
  );
};

export default SearchableMultiSelect;
