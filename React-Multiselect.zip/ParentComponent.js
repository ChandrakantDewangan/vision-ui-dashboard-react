import React, { useState } from 'react';
import SearchableMultiSelect from './SearchableMultiSelect';

const ParentComponent = () => {
  const allOptions = ['Option 1', 'Option 2', 'Option 3', 'Option 4'];
  const [selectedOptions, setSelectedOptions] = useState(['Option 1', 'Option 3']);

  const handleApply = (selectedOptions) => {
    // Do something with the selected options, e.g., update state in the parent component
    setSelectedOptions(selectedOptions);
  };

  const handleCancel = () => {
    // Handle cancel action if needed
    console.log('Cancel button clicked');
  };

  return (
    <div>
      <h2>Parent Component</h2>
      <SearchableMultiSelect
        options={allOptions}
        initialSelectedOptions={selectedOptions}
        onApply={handleApply}
        onCancel={handleCancel}
      />
      <div>
        <p>Selected Options: {selectedOptions.join(', ')}</p>
      </div>
    </div>
  );
};

export default ParentComponent;
