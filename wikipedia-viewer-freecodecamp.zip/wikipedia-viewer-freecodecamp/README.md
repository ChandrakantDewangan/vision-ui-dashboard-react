# Wikipedia Viewer[freecodecamp]

A Pen created on CodePen.io. Original URL: [https://codepen.io/arshdkhn1/pen/pymzWz](https://codepen.io/arshdkhn1/pen/pymzWz).

This app displays the result for the keyword you are searching for using mediawiki api from wikipedia. It also has a button that redirects you to a random wiki topic.